#ifndef INCLUDE_PATTERN_CLUSTER_H_
#define INCLUDE_PATTERN_CLUSTER_H_

#include "utils.h"
#include <cstddef>


namespace pattern_cluster {
using namespace medb2;
/**
 * @brief Defines the input parameter structure for the `PatternCluster` function, 
 * containing various parameters required for pattern clustering.
 */
struct InputParams {
        /**
     * @brief The radius of the pattern, used to determine the effective range of the pattern.
     */
    size_t pattern_radius_ = 0;
    /**
     * @brief The maximum number of clusters to be formed during the clustering process.
     */
    size_t max_clusters_ = 0;
    /**
     * @brief The area constraint parameter, used to limit the area of the clusters.
     */
    double cosine_similarity_constraint_ = 0.0;
    /**
     * @brief The edge move constraint parameter, used to limit the movement of edges during clustering.
     */
    size_t edge_move_constraint_ = 0;
};

// ========== 新增辅助函数声明 ==========

/**
 * @brief 检查点是否严格在marker边界内（包含边界）
 * @param point 需要检查的点
 * @param marker marker边界框
 * @return 如果点在marker内部（包括边界），返回true；否则返回false
 */
bool IsPointInsideMarker(const PointI& point, const BoxI& marker);

/**
 * @brief 提取每个marker对应的pattern内容
 * @param shapes 版图中的所有图形
 * @param center pattern的中心点
 * @param radius pattern的半径（构成pattern_box为中心周围2*radius的正方形）
 * @return 提取的pattern内容（包括pattern_box和polygons）
 */
PatternContents ExtractPattern(const vector<PolygonDataI>& shapes, const PointI& center, size_t radius);

/**
 * @brief 计算两个pattern的余弦相似度
 * @param p1 第一个pattern
 * @param p2 第二个pattern
 * @return 两个pattern的余弦相似度（0-1之间）
 */
double CalculatePatternSimilarity(const PatternContents& p1, const PatternContents& p2);

/**
 * @brief 检查两个pattern是否满足边偏移约束
 * @param p1 第一个pattern
 * @param p2 第二个pattern
 * @param constraint 边偏移约束值
 * @return 如果满足约束，返回true；否则返回false
 */
bool CheckEdgeMovementConstraint(const PatternContents& p1, const PatternContents& p2, size_t constraint);

/**
 * @brief 基于余弦相似度进行聚类
 * @param patterns 所有pattern
 * @param threshold 相似度阈值（0-1之间）
 * @param max_clusters 最大聚类数
 * @param clusters 输出的聚类结果
 */
void ClusterBySimilarity(const vector<PatternContents>& patterns, double threshold, 
                         size_t max_clusters, vector<vector<size_t>>& clusters);

/**
 * @brief 基于边偏移约束进行聚类
 * @param patterns 所有pattern
 * @param constraint 边偏移约束值
 * @param max_clusters 最大聚类数
 * @param clusters 输出的聚类结果
 */
void ClusterByEdgeMovement(const vector<PatternContents>& patterns, size_t constraint,
                           size_t max_clusters, vector<vector<size_t>>& clusters);

/**
 * @brief 从marker中选择最优的pattern中心点
 * 关键修复：确保返回的中心点严格在marker边界内
 * @param shapes 版图中的所有图形
 * @param marker marker边界框
 * @param radius pattern的半径
 * @return 选择的最优中心点（保证在marker内部）
 */
PointI SelectOptimalCenter(const vector<PolygonDataI>& shapes, const BoxI& marker, size_t radius);



void PatternCluster(vector<PolygonDataI> &shapes, vector<BoxI> &markers,
    InputParams &params, vector<PointI> &pattern_centers, vector<vector<size_t>> &clusters);

}  // namespace pattern_cluster

#endif  // INCLUDE_PATTERN_CLUSTER_H_